# racelab/optimizer/utils/__init__.py
from .k1999 import menger_curvature, refine_point, refine_line