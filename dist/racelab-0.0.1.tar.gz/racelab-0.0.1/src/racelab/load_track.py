import numpy as np

def load_track(path):
	return np.load(path)