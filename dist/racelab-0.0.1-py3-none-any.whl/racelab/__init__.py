# racelab/__init__.py
from .load_track import load_track